package com.mycompany.oop2;
public class Oop2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
